import React, { useState, useEffect } from 'react';
import { PenSquare, Search, Star, Tags } from 'lucide-react';
import { Note } from './types';
import NoteEditor from './components/NoteEditor';
import NoteList from './components/NoteList';

export default function App() {
  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem('notes');
    if (saved) {
      const parsed = JSON.parse(saved);
      return parsed.map((note: any) => ({
        ...note,
        createdAt: new Date(note.createdAt),
        updatedAt: new Date(note.updatedAt),
      }));
    }
    return [];
  });

  const [selectedNote, setSelectedNote] = useState<Note | undefined>();
  const [isEditing, setIsEditing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);

  const handleSaveNote = (noteData: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date();
    if (selectedNote) {
      setNotes(notes.map(note =>
        note.id === selectedNote.id
          ? { ...note, ...noteData, updatedAt: now }
          : note
      ));
    } else {
      const newNote: Note = {
        ...noteData,
        id: crypto.randomUUID(),
        createdAt: now,
        updatedAt: now,
      };
      setNotes([newNote, ...notes]);
    }
    setIsEditing(false);
    setSelectedNote(undefined);
  };

  const handleToggleFavorite = (id: string) => {
    setNotes(notes.map(note =>
      note.id === id ? { ...note, favorite: !note.favorite } : note
    ));
  };

  const filteredNotes = notes.filter(note => {
    const matchesSearch = searchQuery
      ? note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        note.content.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    
    const matchesTag = selectedTag
      ? note.tags.includes(selectedTag)
      : true;

    return matchesSearch && matchesTag;
  });

  const allTags = Array.from(new Set(notes.flatMap(note => note.tags)));

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r flex flex-col">
        <div className="p-4 border-b">
          <button
            onClick={() => {
              setSelectedNote(undefined);
              setIsEditing(true);
            }}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            <PenSquare className="w-4 h-4" />
            New Note
          </button>
        </div>

        <div className="p-4 border-b">
          <div className="relative">
            <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search notes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-50 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="p-4 border-b">
          <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
            <Tags className="w-4 h-4" />
            Tags
          </div>
          <div className="flex flex-wrap gap-1">
            {allTags.map(tag => (
              <button
                key={tag}
                onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                className={`px-2 py-1 rounded-full text-xs ${
                  selectedTag === tag
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          <NoteList
            notes={filteredNotes}
            selectedNote={selectedNote}
            onSelect={(note) => {
              setSelectedNote(note);
              setIsEditing(true);
            }}
            onToggleFavorite={handleToggleFavorite}
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {isEditing ? (
          <NoteEditor
            note={selectedNote}
            onSave={handleSaveNote}
            onClose={() => {
              setIsEditing(false);
              setSelectedNote(undefined);
            }}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">
            <div className="text-center">
              <PenSquare className="w-12 h-12 mx-auto mb-4" />
              <h2 className="text-xl font-medium">Select a note or create a new one</h2>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}