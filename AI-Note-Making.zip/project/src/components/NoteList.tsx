import React from 'react';
import { format } from 'date-fns';
import { Star, StarOff } from 'lucide-react';
import { Note } from '../types';

interface NoteListProps {
  notes: Note[];
  selectedNote?: Note;
  onSelect: (note: Note) => void;
  onToggleFavorite: (id: string) => void;
}

export default function NoteList({ notes, selectedNote, onSelect, onToggleFavorite }: NoteListProps) {
  const sortedNotes = [...notes].sort((a, b) => {
    if (a.favorite !== b.favorite) return a.favorite ? -1 : 1;
    return b.updatedAt.getTime() - a.updatedAt.getTime();
  });

  return (
    <div className="divide-y">
      {sortedNotes.map(note => (
        <div
          key={note.id}
          className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors ${
            selectedNote?.id === note.id ? 'bg-blue-50' : ''
          }`}
          onClick={() => onSelect(note)}
        >
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-gray-900 truncate">{note.title}</h3>
              <p className="mt-1 text-sm text-gray-500 line-clamp-2">{note.content}</p>
              
              {note.tags.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {note.tags.map(tag => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 bg-gray-100 text-xs rounded-full text-gray-600"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}
              
              <p className="mt-2 text-xs text-gray-400">
                Updated {format(note.updatedAt, 'MMM d, yyyy')}
              </p>
            </div>
            
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite(note.id);
              }}
              className={`p-1 rounded-full ${
                note.favorite
                  ? 'text-yellow-500 hover:text-yellow-600'
                  : 'text-gray-400 hover:text-gray-500'
              }`}
            >
              {note.favorite ? (
                <Star className="w-5 h-5 fill-current" />
              ) : (
                <StarOff className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}