export interface Note {
  id: string;
  title: string;
  content: string;
  summary?: string;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
  favorite: boolean;
}

export interface Tag {
  id: string;
  name: string;
  color: string;
}